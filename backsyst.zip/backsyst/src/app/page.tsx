"use client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { ClassSection } from "../components/ClassSection";
import { FAQ } from "../components/FAQ";
import { HeroSection } from "../components/HeroSection";
import { ClassFilter } from "../components/ClassFilter";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";

// Data course untuk kelas A-1
const coursesA1 = [
  {
    id: "a1-1",
    title: "Matematika Dasar",
    description: "Pelajari konsep dasar matematika dengan pendekatan yang mudah dipahami",
    duration: "8 minggu",
    students: 45,
    lessons: 24
  },
  {
    id: "a1-2",
    title: "Bahasa Indonesia",
    description: "Meningkatkan kemampuan berbahasa Indonesia yang baik dan benar",
    duration: "6 minggu",
    students: 52,
    lessons: 18
  },
  {
    id: "a1-3",
    title: "IPA Terpadu",
    description: "Eksplorasi dunia sains melalui eksperimen dan praktik langsung",
    duration: "10 minggu",
    students: 38,
    lessons: 30
  }
];

// Data course untuk kelas A-2
const coursesA2 = [
  {
    id: "a2-1",
    title: "Matematika Lanjutan",
    description: "Konsep matematika tingkat menengah dengan aplikasi praktis",
    duration: "10 minggu",
    students: 42,
    lessons: 28
  },
  {
    id: "a2-2",
    title: "Bahasa Inggris",
    description: "Pelajari bahasa Inggris untuk komunikasi sehari-hari dan akademik",
    duration: "8 minggu",
    students: 48,
    lessons: 32
  },
  {
    id: "a2-3",
    title: "Sejarah Indonesia",
    description: "Memahami perjalanan sejarah bangsa Indonesia dari masa ke masa",
    duration: "6 minggu",
    students: 35,
    lessons: 20
  }
];

export default function HomePage() {
  const handleFilterChange = (filters: any) => {
    console.log('Filters changed:', filters);
    // Handle filter logic here
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Classes Section */}
        <section className="space-y-8">
          <div className="text-center">
            <h2 className="mb-4">Jelajahi Course Kami</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Kami menyediakan course yang disesuaikan dengan tingkat kelas. 
              Pilih kelas Anda dan mulai perjalanan belajar yang menarik.
            </p>
          </div>
          
          <div className="flex gap-8">
            {/* Sidebar Filter */}
            <div className="hidden lg:block flex-shrink-0">
              <ClassFilter onFilterChange={handleFilterChange} />
            </div>

            {/* Main Content Area */}
            <div className="flex-1">
              <Tabs defaultValue="a1" className="w-full">
                <div className="flex justify-center mb-8">
                  <TabsList className="grid w-full max-w-md grid-cols-2">
                    <TabsTrigger value="a1">Kelas A-1</TabsTrigger>
                    <TabsTrigger value="a2">Kelas A-2</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="a1">
                  <ClassSection 
                    className="A-1" 
                    courses={coursesA1} 
                    onCourseSelect={(id) => {
                      // This will be handled by Next.js routing
                      window.location.href = `/course/${id}`;
                    }}
                  />
                </TabsContent>
                <TabsContent value="a2">
                  <ClassSection 
                    className="A-2" 
                    courses={coursesA2}
                    onCourseSelect={(id) => {
                      // This will be handled by Next.js routing
                      window.location.href = `/course/${id}`;
                    }}
                  />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="bg-muted/30 -mx-4 px-4 py-16 mt-20">
          <div className="container mx-auto">
            <FAQ />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}