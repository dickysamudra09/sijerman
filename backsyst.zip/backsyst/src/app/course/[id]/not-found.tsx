import Link from "next/link";
import { Button } from "../../../components/ui/button";
import { Header } from "../../../components/Header";
import { Footer } from "../../../components/Footer";
import { BookOpen, ArrowLeft } from "lucide-react";

export default function CourseNotFound() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1 flex items-center justify-center py-20">
        <div className="text-center space-y-6 max-w-md">
          <div className="mx-auto w-24 h-24 bg-muted rounded-full flex items-center justify-center">
            <BookOpen className="h-12 w-12 text-muted-foreground" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-bold">Course Tidak Ditemukan</h1>
            <p className="text-muted-foreground">
              Maaf, course yang Anda cari tidak tersedia atau mungkin telah dihapus.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Kembali ke Beranda
              </Button>
            </Link>
            <Button variant="outline">
              Lihat Course Lain
            </Button>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}