import { CourseDetail } from "../../../components/CourseDetail";
import { Header } from "../../../components/Header";
import { Footer } from "../../../components/Footer";
import { notFound } from 'next/navigation';

// Sample course data - in real app this would come from database
const courseData = {
  "a1-1": {
    id: "a1-1",
    title: "Matematika Dasar",
    description: "Pelajari konsep dasar matematika dengan pendekatan yang mudah dipahami. Course ini dirancang khusus untuk siswa kelas A-1 dengan metode pembelajaran interaktif dan contoh praktis dalam kehidupan sehari-hari.",
    instructor: "Dr. Ahmad Sutrisno",
    duration: "8 minggu",
    students: 45,
    lessons: 24,
    rating: 4.8,
    price: "Gratis",
    level: "Pemula",
    category: "Matematika",
    thumbnail: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&h=450&fit=crop",
    progress: 35,
    enrolled: true
  },
  "a1-2": {
    id: "a1-2",
    title: "Bahasa Indonesia",
    description: "Meningkatkan kemampuan berbahasa Indonesia yang baik dan benar. Pelajari tata bahasa, keterampilan menulis, dan kemampuan komunikasi yang efektif.",
    instructor: "Prof. Siti Nurhaliza",
    duration: "6 minggu",
    students: 52,
    lessons: 18,
    rating: 4.6,
    price: "Gratis",
    level: "Pemula",
    category: "Bahasa",
    thumbnail: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800&h=450&fit=crop",
    progress: 0,
    enrolled: false
  },
  "a1-3": {
    id: "a1-3",
    title: "IPA Terpadu",
    description: "Eksplorasi dunia sains melalui eksperimen dan praktik langsung. Memahami konsep fisika, kimia, dan biologi secara terintegrasi.",
    instructor: "Dr. Budi Santoso",
    duration: "10 minggu",
    students: 38,
    lessons: 30,
    rating: 4.9,
    price: "Gratis",
    level: "Pemula",
    category: "Sains",
    thumbnail: "https://images.unsplash.com/photo-1582719471079-b3adcf9b9e7a?w=800&h=450&fit=crop",
    progress: 0,
    enrolled: false
  },
  "a2-1": {
    id: "a2-1",
    title: "Matematika Lanjutan",
    description: "Konsep matematika tingkat menengah dengan aplikasi praktis dalam kehidupan sehari-hari dan persiapan untuk tingkat yang lebih advanced.",
    instructor: "Dr. Ahmad Sutrisno",
    duration: "10 minggu",
    students: 42,
    lessons: 28,
    rating: 4.7,
    price: "Gratis",
    level: "Menengah",
    category: "Matematika",
    thumbnail: "https://images.unsplash.com/photo-1596495578065-6e0763fa1178?w=800&h=450&fit=crop",
    progress: 0,
    enrolled: false
  },
  "a2-2": {
    id: "a2-2",
    title: "Bahasa Inggris",
    description: "Pelajari bahasa Inggris untuk komunikasi sehari-hari dan akademik. Fokus pada grammar, vocabulary, speaking, dan listening skills.",
    instructor: "Ms. Jennifer Smith",
    duration: "8 minggu",
    students: 48,
    lessons: 32,
    rating: 4.8,
    price: "Gratis",
    level: "Menengah",
    category: "Bahasa",
    thumbnail: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&h=450&fit=crop",
    progress: 0,
    enrolled: false
  },
  "a2-3": {
    id: "a2-3",
    title: "Sejarah Indonesia",
    description: "Memahami perjalanan sejarah bangsa Indonesia dari masa ke masa. Dari zaman prasejarah hingga era modern dengan pendekatan yang menarik.",
    instructor: "Prof. Susilo Bambang",
    duration: "6 minggu",
    students: 35,
    lessons: 20,
    rating: 4.5,
    price: "Gratis",
    level: "Menengah",
    category: "Sejarah",
    thumbnail: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=450&fit=crop",
    progress: 0,
    enrolled: false
  }
};

interface CoursePageProps {
  params: {
    id: string;
  };
}

export async function generateMetadata({ params }: CoursePageProps) {
  const course = courseData[params.id as keyof typeof courseData];
  
  if (!course) {
    return {
      title: 'Course Not Found - EduPlatform',
    };
  }

  return {
    title: `${course.title} - EduPlatform`,
    description: course.description,
  };
}

export default function CoursePage({ params }: CoursePageProps) {
  const courseExists = courseData[params.id as keyof typeof courseData];

  if (!courseExists) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <CourseDetail 
        courseId={params.id}
        onBack={() => {
          if (typeof window !== 'undefined') {
            window.history.back();
          }
        }}
      />
      <Footer />
    </div>
  );
}

// Generate static params for all courses
export async function generateStaticParams() {
  return Object.keys(courseData).map((id) => ({
    id: id,
  }));
}