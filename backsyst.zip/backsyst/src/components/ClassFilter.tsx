import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Filter, BookOpen, Clock, Users, Star } from "lucide-react";

interface FilterOption {
  id: string;
  label: string;
  count: number;
}

interface ClassFilterProps {
  onFilterChange: (filters: any) => void;
}

export function ClassFilter({ onFilterChange }: ClassFilterProps) {
  const classOptions: FilterOption[] = [
    { id: "a1", label: "Kelas A-1", count: 3 },
    { id: "a2", label: "Kelas A-2", count: 3 }
  ];

  const subjectOptions: FilterOption[] = [
    { id: "math", label: "Matematika", count: 2 },
    { id: "science", label: "IPA", count: 1 },
    { id: "indonesian", label: "Bahasa Indonesia", count: 1 },
    { id: "english", label: "Bahasa Inggris", count: 1 },
    { id: "history", label: "Sejarah", count: 1 }
  ];

  const durationOptions: FilterOption[] = [
    { id: "short", label: "1-6 minggu", count: 2 },
    { id: "medium", label: "7-10 minggu", count: 3 },
    { id: "long", label: "11+ minggu", count: 1 }
  ];

  const difficultyOptions: FilterOption[] = [
    { id: "beginner", label: "Pemula", count: 3 },
    { id: "intermediate", label: "Menengah", count: 2 },
    { id: "advanced", label: "Lanjutan", count: 1 }
  ];

  return (
    <div className="w-72 space-y-6">
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Kursus
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Class Filter */}
          <div className="space-y-3">
            <h4 className="font-medium">Kelas</h4>
            {classOptions.map((option) => (
              <div key={option.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id={option.id} />
                  <label 
                    htmlFor={option.id} 
                    className="text-sm font-normal cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <Badge variant="secondary" className="h-5 px-2">
                  {option.count}
                </Badge>
              </div>
            ))}
          </div>

          <Separator />

          {/* Subject Filter */}
          <div className="space-y-3">
            <h4 className="font-medium">Mata Pelajaran</h4>
            {subjectOptions.map((option) => (
              <div key={option.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id={option.id} />
                  <label 
                    htmlFor={option.id} 
                    className="text-sm font-normal cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <Badge variant="secondary" className="h-5 px-2">
                  {option.count}
                </Badge>
              </div>
            ))}
          </div>

          <Separator />

          {/* Duration Filter */}
          <div className="space-y-3">
            <h4 className="font-medium flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Durasi
            </h4>
            {durationOptions.map((option) => (
              <div key={option.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id={option.id} />
                  <label 
                    htmlFor={option.id} 
                    className="text-sm font-normal cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <Badge variant="secondary" className="h-5 px-2">
                  {option.count}
                </Badge>
              </div>
            ))}
          </div>

          <Separator />

          {/* Difficulty Filter */}
          <div className="space-y-3">
            <h4 className="font-medium flex items-center gap-2">
              <Star className="h-4 w-4" />
              Tingkat Kesulitan
            </h4>
            {difficultyOptions.map((option) => (
              <div key={option.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id={option.id} />
                  <label 
                    htmlFor={option.id} 
                    className="text-sm font-normal cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
                <Badge variant="secondary" className="h-5 px-2">
                  {option.count}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}