import { GraduationCap } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t bg-muted/30 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="font-bold">EduPlatform</span>
            </div>
            <p className="text-muted-foreground text-sm">
              Platform pembelajaran online terbaik untuk siswa Indonesia
            </p>
          </div>
          <div>
            <h4 className="font-medium mb-4">Course</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Kelas A-1</li>
              <li>Kelas A-2</li>
              <li>Course Gratis</li>
              <li>Sertifikasi</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-4">Dukungan</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>FAQ</li>
              <li>Bantuan</li>
              <li>Kontak</li>
              <li>Forum</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-4">Perusahaan</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Tentang Kami</li>
              <li>Karir</li>
              <li>Blog</li>
              <li>Privacy Policy</li>
            </ul>
          </div>
        </div>
        <div className="border-t mt-8 pt-8 text-center text-muted-foreground text-sm">
          <p>&copy; 2025 EduPlatform. Semua hak dilindungi.</p>
        </div>
      </div>
    </footer>
  );
}