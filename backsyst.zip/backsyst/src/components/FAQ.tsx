import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "Bagaimana cara mendaftar untuk course?",
    answer: "Anda dapat mendaftar dengan mengklik tombol 'Lihat Detail' pada card course yang diinginkan, kemudian ikuti instruksi pendaftaran."
  },
  {
    question: "Apakah ada biaya untuk mengikuti course?",
    answer: "Sebagian course gratis dan sebagian berbayar. Informasi biaya akan ditampilkan pada halaman detail course."
  },
  {
    question: "Berapa lama durasi setiap course?",
    answer: "Durasi course bervariasi tergantung pada materi yang diajarkan. Umumnya berkisar antara 2-12 minggu."
  },
  {
    question: "Apakah ada sertifikat setelah menyelesaikan course?",
    answer: "Ya, Anda akan mendapatkan sertifikat digital setelah menyelesaikan course dan lulus ujian akhir."
  },
  {
    question: "Bisakah mengakses course dari perangkat mobile?",
    answer: "Ya, platform kami responsif dan dapat diakses dari berbagai perangkat termasuk smartphone dan tablet."
  },
  {
    question: "Bagaimana jika saya kesulitan dalam mengikuti course?",
    answer: "Kami menyediakan forum diskusi dan dukungan tutor untuk membantu siswa yang mengalami kesulitan."
  }
];

export function FAQ() {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="mb-2">Frequently Asked Questions</h2>
        <p className="text-muted-foreground">
          Pertanyaan yang sering diajukan tentang course kami
        </p>
      </div>
      <Accordion type="single" collapsible className="w-full max-w-3xl mx-auto">
        {faqData.map((item, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="text-left">
              {item.question}
            </AccordionTrigger>
            <AccordionContent>
              {item.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}