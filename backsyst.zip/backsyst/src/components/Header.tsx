"use client";

import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { AuthDialog } from "./AuthDialog";
import { GraduationCap, User, Search } from "lucide-react";

export function Header() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-xl font-bold">EduPlatform</h1>
              <p className="text-sm text-muted-foreground">Belajar tanpa batas</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-4 flex-1 max-w-md mx-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari course, materi, atau topik..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <AuthDialog>
              <Button variant="ghost" size="sm">
                <User className="h-4 w-4 mr-2" />
                Masuk
              </Button>
            </AuthDialog>
            <AuthDialog>
              <Button size="sm">
                Daftar Gratis
              </Button>
            </AuthDialog>
          </div>
        </div>
      </div>
    </header>
  );
}